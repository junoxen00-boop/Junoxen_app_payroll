<div class="row g-3">

    {{-- EARNINGS --}}
    <div class="col-12">
        <h5 class="fw-bold mb-2">Earnings</h5>
    </div>

    @foreach([
        'basic_salary' => 'Basic Salary',
        'hra' => 'HRA',
        'conveyance_allowance' => 'Conveyance Allowance',
        'medical_allowance' => 'Medical Allowance',
        'special_allowance' => 'Special Allowance',
        'other_allowance' => 'Other Allowance',
        'overtime_hours' => 'Overtime Hours',
        'bonus' => 'Bonus',
        'incentive' => 'Incentive',
        'reimbursement' => 'Reimbursement',
        'other_earnings' => 'Other Earnings',
    ] as $name => $label)

        <div class="col-md-4">
            <label class="form-label">{{ $label }}</label>

            <input
                type="number"
                step="0.01"
                min="0"
                name="{{ $name }}"
                class="form-control"
                value="{{ old($name, isset($payroll) ? $payroll->{$name} : 0) }}"
            >
        </div>

    @endforeach


    {{-- DEDUCTIONS --}}
    <div class="col-12 mt-4">
        <h5 class="fw-bold mb-2">Deductions</h5>
    </div>

    @foreach([
        'pf_deduction' => 'PF Deduction',
        'esi_deduction' => 'ESI Deduction',
        'professional_tax' => 'Professional Tax',
        'tds' => 'TDS',
        'loan_deduction' => 'Loan Deduction',
        'leave_deduction' => 'Leave Deduction',
        'other_deduction' => 'Other Deduction',
    ] as $name => $label)

        <div class="col-md-4">
            <label class="form-label">{{ $label }}</label>

            <input
                type="number"
                step="0.01"
                min="0"
                name="{{ $name }}"
                class="form-control"
                value="{{ old($name, isset($payroll) ? $payroll->{$name} : 0) }}"
            >
        </div>

    @endforeach


    {{-- STATUS --}}
    <div class="col-md-4">
        <label class="form-label">Status</label>

        <select name="status" class="form-select">

            <option
                value="Draft"
                @selected(old('status', $payroll->status ?? 'Draft') === 'Draft')
            >
                Draft
            </option>

            <option
                value="Generated"
                @selected(old('status', $payroll->status ?? '') === 'Generated')
            >
                Generated
            </option>

            <option
                value="Paid"
                @selected(old('status', $payroll->status ?? '') === 'Paid')
            >
                Paid
            </option>

            <option
                value="Cancelled"
                @selected(old('status', $payroll->status ?? '') === 'Cancelled')
            >
                Cancelled
            </option>

        </select>
    </div>

</div>