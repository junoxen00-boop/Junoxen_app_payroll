@csrf
@if(isset($salaryStructure)) @method('PUT') @endif
<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Employee *</label>
        <select name="employee_id" class="form-select" required>
            <option value="">Select employee</option>
            @foreach($employees as $employee)
                <option value="{{ $employee->id }}" @selected(old('employee_id', $salaryStructure->employee_id ?? '') == $employee->id)>{{ $employee->employee_id }} - {{ $employee->full_name }}</option>
            @endforeach
        </select>
    </div>
    <div class="col-md-3"><label class="form-label">Effective From *</label><input type="date" name="effective_from" class="form-control" required value="{{ old('effective_from', isset($salaryStructure) ? $salaryStructure->effective_from?->format('Y-m-d') : now()->startOfMonth()->format('Y-m-d')) }}"></div>
    <div class="col-md-3"><label class="form-label">Effective To</label><input type="date" name="effective_to" class="form-control" value="{{ old('effective_to', isset($salaryStructure) ? $salaryStructure->effective_to?->format('Y-m-d') : '') }}"></div>

    @php
        $fields = [
            'basic_salary'=>'Basic Salary *','hra'=>'HRA','conveyance_allowance'=>'Conveyance Allowance','medical_allowance'=>'Medical Allowance',
            'special_allowance'=>'Special Allowance','other_allowance'=>'Other Allowance','overtime_rate'=>'Overtime Rate / Hour','pf_deduction'=>'PF Deduction',
            'esi_deduction'=>'ESI Deduction','professional_tax'=>'Professional Tax','tds'=>'TDS','loan_deduction'=>'Loan Deduction','other_deduction'=>'Other Deduction'
        ];
    @endphp
    @foreach($fields as $name=>$label)
        <div class="col-md-4">
            <label class="form-label">{{ $label }}</label>
            <div class="input-group"><span class="input-group-text">₹</span><input type="number" step="0.01" min="0" name="{{ $name }}" class="form-control" value="{{ old($name, $salaryStructure->{$name} ?? 0) }}" {{ $name==='basic_salary' ? 'required' : '' }}></div>
        </div>
    @endforeach
    <div class="col-md-4"><label class="form-label">Status *</label><select name="status" class="form-select" required><option value="Active" @selected(old('status',$salaryStructure->status ?? 'Active')==='Active')>Active</option><option value="Inactive" @selected(old('status',$salaryStructure->status ?? '')==='Inactive')>Inactive</option></select></div>
    <div class="col-12"><label class="form-label">Notes</label><textarea name="notes" class="form-control" rows="3">{{ old('notes',$salaryStructure->notes ?? '') }}</textarea></div>
</div>
@if($errors->any())<div class="alert alert-danger mt-3"><ul class="mb-0">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
<div class="d-flex gap-2 mt-4"><button class="btn btn-primary"><i class="bi bi-save me-1"></i> Save Salary Structure</button><a href="{{ route('admin.salary-structures.index') }}" class="btn btn-outline-secondary">Cancel</a></div>
