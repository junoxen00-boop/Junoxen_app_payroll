@extends('layouts.admin')
@section('content')
<div class="d-flex justify-content-between align-items-center mb-4"><div><h3 class="fw-bold mb-1">Create Salary Structure</h3><p class="text-muted mb-0">Define the employee's recurring earnings and deductions.</p></div></div>
<div class="card"><div class="card-body p-4"><form method="POST" action="{{ route('admin.salary-structures.store') }}">@include('admin.salary-structures._form')</form></div></div>
@endsection
